# units
|base_unit|coefficient|description|id|is_error|name|
|--|--|--|--|--|--|
||1||a949aa90960b42e69c6188e0c4f9a992|True|грамм|