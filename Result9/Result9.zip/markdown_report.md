# unit_model
|base_unit|coefficient|description|id|is_error|name|
|--|--|--|--|--|--|
||1||61de36995b834045851fabdc217de365|True|грамм|