# units
|base_unit|coefficient|description|id|is_error|name|
|--|--|--|--|--|--|
||1||e0f28180fb52408f8ea71f853ab71032|True|грамм|